// Muestra contenido oculto al hacer clic en el botón
document.getElementById('mostrarMas').addEventListener('click', function () {
    const contenido = document.getElementById('contenidoOculto');
    if (contenido.style.display === 'none') {
        contenido.style.display = 'block';
        this.textContent = 'Leer menos';
    } else {
        contenido.style.display = 'none';
        this.textContent = 'Leer más';
    }
});
